<div class="slidermain">
    <a href="" class="slide" onclick=""><img src="img/arrow.png"></a>
    <div style="
  border: 1px dotted black;
  overflow-y: hidden;
  overflow-x: scroll;
  display: flex;
  width: 300px;">
  
<div class="slider1">

</div>
<div class="slider1">

</div>

<div class="slider1">

</div>
<div class="slider1">

</div>
<div class="slider1">

</div>
</div>
</div>

.slidermain{
height: 500px;
width: 100%;
background-color: red;
padding-top: 100px;
display: flex;
}

.slider1{
  width: 450px;
  background-color: black;
  height: 450px;
  margin-left: 100px;
padding-top: 0px;
overflow: visible;
}
.slide {
   margin-top: 150px;

}
.slidermain img{
  width: 30px;
  height: 40px;
}