
 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title></title>
 </head>
 <body>
 <a href="Welcome"><?php echo "rushi"; ?></a>
 </body>
 </html>
