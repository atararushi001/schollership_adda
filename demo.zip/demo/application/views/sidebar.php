<header  id="sty">
<nav>
<div class="logo"> 
<img src="img/logo.png" id="lo" > 
</div>
<style type="text/css">
    .mySlides,header,nav,nav ul{
   display: block !important;

    }

</style>
<ul>
  
  <li><a href="#home" class="active">Home</a></li>
  <li class="dropdown">
    <a href="" class="dropbtn">engineering</a>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </li>
   <li class="dropdown">
    <a href="" class="dropbtn">medical</a>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="" class="dropbtn">management</a>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </li>
  <li class="dropdown">
    <a href="" class="dropbtn">more</a>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </li>

</ul>
<div class="loginbtn">
<ul>
<a href="" ><i class="fas fa-sign-in-alt "></i></a>
 <li><a href="#home">login</a></li>
<a href="" ><i class="fas fa-grip-lines-vertical"></i></a>
 <li><a href="#home">register</a></li>
</ul>
</div>

</nav>
</header>

