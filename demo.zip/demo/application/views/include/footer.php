<footer>
	
<div class="foot">	
<div class="main">
	<div style="width: 90%; margin: auto; height: 80px; display: flex;">
<div class="logo1"> 
<img src="<?php echo base_url()?>asset/img/logo1.png" > 
</div>
   <div class="lastfooter">
<h3><i class="fas fa-grip-lines-vertical"></i> सा विद्या या विमुक्तये <i class="fas fa-grip-lines-vertical"></i></h3>
</div>  
<div class="main2">
<i class="fab fa-facebook-f fa-1x"></i>
 <i class="fab fa-linkedin-in fa-1x"></i>
<i class="fab fa-twitter fa-1x"></i>
 <i class="fab fa-google fa-1x"></i>
</div>
</div>
</div>
<div class="main3" >
<div class="courses">
 <h3>   &nbsp;&nbsp;Major Courses</h3>
 <div  class="branch">	
 	<ul>
		  <li>&nbsp;  &nbsp; Medical</li>
			<li>Engineering</li>
	</ul>

    <ul>
        <li> &nbsp;  &nbsp; Science</li>
	    
		<li>Management</li>
	</ul>
</div>
</div>

<div class="HelpfulLinks">
	
<h3>Helpful Links</h3>
 <ul>
  <li><a href="Contact.php">Contact</a></li>
  <li><a href="about.php">About us</a></li>
</ul>
</div>

<div class="Account">
	<h3>Account</h3>
 <ul>
  <li><a href="Contact.php">Log In </a></li>
  <li><a href="register.php">Register</a></li>
</ul>
</div>



<div class="msjbox">
	<h3><i class="far fa-envelope"></i> Sign Up For a Newsletter</h3>
	<p> Weekly breaking news, analysis and cutting edge advices on job searching.</p>
	<div class="msj2">  
	<input type="email" name="msjemail" class="msjemail" placeholder="Enter Your Email Address"> 
	<button ><i class="fas fa-location-arrow"></i></button>
</div>
</div>
</div>

<div class="last1">
<h3>© 2021 <strong> Scholarship Adda</strong>. All Rights Reserved. </h3>	
</div>
</div>
</footer>